import java.util.Random;

/**
 * Utilities class.
 * 
 * @author Todor Balabanov
 */
class Util {

	/**
	 * Pseudo-random number generator.
	 */
	static final Random PRNG = new Random();

}
